# node-red-contrib-mqtt-connection-check

A Node Red node that checks the connectivity with an MQTT broker.

The check result is returned in msg.mqttCheck object.
